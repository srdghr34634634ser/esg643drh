delete from integration_actions where server_id = :server_id: and integration_id = :integration_id:;
delete from integrations where server_id = :server_id: and integration_id = :integration_id:;
insert into :tablename: ( server_id, id, ident, value, string_id) 
 values( :server_id:, 0, :ident*:, :value*:, :string_id: )
 [[[,(:server_id:, 0, :ident*:, :value*:, :string_id:)]]]
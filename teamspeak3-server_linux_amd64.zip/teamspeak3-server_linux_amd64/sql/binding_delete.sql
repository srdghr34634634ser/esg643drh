delete from bindings where binding_id=:binding_id:;
